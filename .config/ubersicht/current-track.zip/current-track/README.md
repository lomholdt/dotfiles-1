# current-track
A chrome extension that notifies com.callahanrts.bar of currently playing tracks

## Installation

*This chrome extension is not currently available in the chrome webstore as it was removed by Google.
While this issue is being addressed, you can install the extension manually.*

1. Download, or clone this repository
1. Go to <a href="chrome://extensions/" target="_blank">chrome://extensions/</a>
1. Click load unpacked extension
1. Select this extensions folder
