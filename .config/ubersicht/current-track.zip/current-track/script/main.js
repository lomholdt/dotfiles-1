
host = window.location.hostname;
var notifications = true;

setInterval(function(){
  var track;
  state = {}

  if(host.indexOf("youtube") > -1) {
    state.playing = youtubePlaying();
    state.track = state.playing ? youtube() : "";
    state.source = "youtube";
  } else if(host.indexOf("soundcloud") > -1) {
    state.playing = soundcloudPlaying();
    state.track = state.playing ? soundcloud() : "";
    state.source = "soundcloud";
  }

  if(notifications){
    chrome.runtime.sendMessage(state);
  }

  notifications = state.playing;

}, 1000);

var youtube = function(){
  track = document.getElementsByClassName("watch-title")[0].innerHTML;
  return track.replace(/\n/g, "").replace(/^\s*/, "").replace(/\s*$/, "");
};

var youtubePlaying = function(){
  btn = document.getElementsByClassName("ytp-play-button")[0];
  action = btn.getAttribute("aria-label")
  return  !!action && action.toLowerCase() == "pause"; // Pause action available while playing
};

var soundcloud = function(){
  return document.getElementsByTagName("title")[0].text;
};

var soundcloudPlaying = function(){
  return document.getElementsByClassName("m-playing")[0] != undefined
};

