var port = null;

function sendNativeMessage(message) {
  port.postMessage(message);
  console.log("Sent message: " + JSON.stringify(message));
}

function onNativeMessage(message) {
  console.log("Received message: " + JSON.stringify(message));
}

function onDisconnected() {
  console.log("Failed to connect: " + chrome.runtime.lastError.message);
  port = null;
  connect();
}

function connect() {
  var hostName = "com.callahanrts.bar";
  console.log("Connecting to native messaging host" + hostName)
  port = chrome.runtime.connectNative(hostName);
  port.onMessage.addListener(onNativeMessage);
  port.onDisconnect.addListener(onDisconnected);
}

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    console.log(request);
    sendNativeMessage(request);
  }
);

document.addEventListener('DOMContentLoaded', function () {
  connect();
});

